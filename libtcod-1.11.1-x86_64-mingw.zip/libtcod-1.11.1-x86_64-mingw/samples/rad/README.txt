
Radiosity 0.1.0

“Radiosity” engine

Simple light diffusion using some sort of radiosity algorithm
Not fast, not clean code… To be improved

http://doryen.eptalys.net/demos/

